﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcStrToMathE
{
    public class ExcToMath
    {
        /// <summary>  
        /// 执行Excel中的宏  
        /// </summary>  
        /// <param name="excelFilePath">Excel文件路径</param>  
        /// <param name="macroName">宏名称</param>  
        /// <param name="parameters">宏参数组</param>  
        public void RunWordMacro(string excelFilePath, object[] macroName, object[] parameters)
        {
            #region 定義OPEN參數
            Object confirmConversions = Type.Missing;
            Object readOnly = Type.Missing;
            Object addToRecentFiles = Type.Missing;
            Object passwordDocument = Type.Missing;
            Object passwordTemplate = Type.Missing;
            Object revert = Type.Missing;
            Object writePasswordDocument = Type.Missing;
            Object writePasswordTemplate = Type.Missing;
            Object format = Type.Missing;
            Object encoding = Type.Missing;
            Object visible = Type.Missing;
            Object openConflictDocument = Type.Missing;
            Object openAndRepair = Type.Missing;
            Object documentDirection = Type.Missing;
            Object noEncodingDialog = Type.Missing;
            #endregion
            try
            {
                //macroName = "MTCommand_TeXToggle";
                #region 调用宏处理
                object appath = excelFilePath;
                // 准备打开Excel文件时的缺省参数对象  
                object oMissing = System.Reflection.Missing.Value;

                object objTrue = true;

                _Application oWord = new Application();
                _Document document = null;
                oWord.Documents.Open(ref appath, ref confirmConversions, ref readOnly, ref addToRecentFiles, ref passwordDocument, ref passwordTemplate, ref revert,
                    ref writePasswordDocument, ref writePasswordTemplate, ref format, ref encoding, ref visible, ref openConflictDocument, ref openAndRepair, 
                    ref documentDirection, ref noEncodingDialog);

                oWord.Visible = false;//word文件不可见
                //object oTemplate = excelFilePath + @"\" + @"BDA0001072554390000231.docx";//word文件地址

                object oTemplate = excelFilePath;

                document = oWord.ActiveDocument;

                //Documents docs = oWord.Documents;
                try
                {
                    RunMacro(oWord, macroName);
                }
                catch (Exception ex) { }

                // 保存更改  
                document.Save();

                // 退出document  
                document.Close(false, oMissing, oMissing);

                #endregion

                #region 释放对象

                // 关闭Word  
                oWord.Quit();

                // 释放document对象  
                System.Runtime.InteropServices.Marshal.ReleaseComObject(document);
                document = null;

                // 释放Word对象  
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oWord);
                oWord = null;

                // 调用垃圾回收  
                GC.Collect();
                #region
                //try
                //{
                //    document = oWord.Documents.Add(ref oTemplate, ref oMissing, ref oMissing, ref oMissing);
                //}
                //catch (Exception ex)
                //{
                //    //oWord.Quit();
                //}
                //finally
                //{
                //    //打开文件
                //    Type docsType = oTemplate.GetType();

                //    //document = oWord.ActiveDocument;

                //    object[] MacroName = new object[] { "MTCommand_TeXToggle" };

                //    try
                //    {
                //        RunMacro(oWord, MacroName);
                //        // 保存更改  
                //        document.Save();
                //    }
                //    catch (Exception ex) { }

                //    // 退出document  
                //    document.Close(false, oMissing, oMissing);

                //    #endregion

                //    #region 释放对象

                //    // 关闭Word  
                //    oWord.Quit();

                //    // 释放document对象  
                //    System.Runtime.InteropServices.Marshal.ReleaseComObject(document);
                //    document = null;

                //    // 释放Word对象  
                //    System.Runtime.InteropServices.Marshal.ReleaseComObject(oWord);
                //    oWord = null;

                //    // 调用垃圾回收  
                //    GC.Collect();
                //}
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                //throw ex;
            }
            finally
            {
                // 调用垃圾回收  
                GC.Collect();
            }
        }


        private object RunMacro(object oApp, object[] oRunArgs)
        {
            try
            {
                // 声明一个返回对象  
                object objRtn;

                // 反射方式执行宏  
                objRtn = oApp.GetType().InvokeMember("Run", System.Reflection.BindingFlags.Default | System.Reflection.BindingFlags.InvokeMethod, null, oApp, oRunArgs);

                // 返回值  
                return objRtn;

            }
            catch (Exception ex)
            {
                // 如果有底层异常，抛出底层异常  
                if (ex.InnerException.Message.ToString().Length > 0)
                {
                    throw ex.InnerException;
                }
                else
                {
                    throw ex;
                }
            }
            finally
            {

            }
        }
    }
}
