﻿using ExcStrToMathE;
using NPOI.XWPF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtractFileToStr
{
    public class ExtractToStr
    {
        /// <summary>
        /// 提取内容方法
        /// </summary>
        /// <param name="path">源文件路径</param>
        /// <returns></returns>
        public string Extract(string path, string startTag, string endTag, string[] Suffix)
        {
            string msg = string.Empty;
            string file = "";
            string[] SourceFiles = Directory.GetFiles(path, "*.mml", SearchOption.TopDirectoryOnly);
            if (SourceFiles.Length > 0)
            {
                try
                {
                    for (int i = 0; i < SourceFiles.Length; i++)
                    {
                        string content = File.ReadAllText(SourceFiles[i]);
                        string startStr = startTag;
                        int startnum = content.IndexOf(startStr) + startStr.Length;
                        int endnum = content.IndexOf(endTag);
                        string ExtractContent = "$" + content.Substring(startnum, endnum - startnum) + "$";

                        for (int j = 0; j < Suffix.Length; j++)
                        {
                            file = Path.GetDirectoryName(SourceFiles[i]) + "\\" + Path.GetFileNameWithoutExtension(SourceFiles[i]) + Suffix[j];

                            if (Suffix[j].Equals(".doc", StringComparison.InvariantCultureIgnoreCase) || Suffix[j].Equals(".docx", StringComparison.InvariantCultureIgnoreCase))
                            {
                                XWPFDocument xwpf = new XWPFDocument(); //文档

                                XWPFParagraph p1 = xwpf.CreateParagraph(); //段落
                                p1.Alignment = ParagraphAlignment.LEFT; //字体居中

                                XWPFRun r1 = p1.CreateRun();                //向该段落中添加文字
                                r1.SetText("" + ExtractContent + "");

                                FileStream fs = new FileStream(file, FileMode.Create);//创建文件流
                                xwpf.Write(fs);
                                fs.Close();
                                try
                                {
                                    object[] macroName = new object[] { "MTCommand_TeXToggle" };
                                    object[] parameters = new object[] { "" };
                                    ExcToMath etm = new ExcToMath();
                                    etm.RunWordMacro(file, macroName, parameters);
                                }
                                catch (Exception ex) {
                                    msg = ex.ToString();
                                }
                            }
                            else
                            {
                                if (!File.Exists(file))
                                {
                                    //没有则创建这个文件
                                    FileStream fs1 = new FileStream(file, FileMode.Create, FileAccess.Write);//创建写入文件
                                    StreamWriter sw = new StreamWriter(fs1);
                                    sw.WriteLine(ExtractContent);//开始写入值
                                    sw.Close();
                                    fs1.Close();
                                }
                            }
                        }
                    }
                    msg = "生成完成";
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else
            {
                msg = "当前路径下没有源文件";
            }
            return msg;
        }
    }
}
