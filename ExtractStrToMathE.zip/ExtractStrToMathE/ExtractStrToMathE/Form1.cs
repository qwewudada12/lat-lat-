﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExtractFileToStr;
using ExcStrToMathE;

namespace ExtractStrToMathE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_SelPath_Click(object sender, EventArgs e)
        {
            //ExcToMath ww = new ExcToMath();
            //object aa = new object();
            //ww.RunWordMacro(Application.StartupPath.ToString(), "", new object[] { });
            //return;
            FolderBrowserDialog path = new FolderBrowserDialog();
            path.ShowDialog();
            string paths = path.SelectedPath;

            MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
            DialogResult dr = MessageBox.Show("确定生成文件吗?", "退出系统", messButton);

            string[] Suffix = { ".lat", ".docx" };
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                ExtractToStr ets = new ExtractToStr();
                MessageBox.Show(ets.Extract(paths, "<annotation encoding='application/x-tex'>", "</annotation></semantics></math>", Suffix));
            }
        }
    }
}
