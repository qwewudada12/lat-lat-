﻿namespace ExtractStrToMathE
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btn_SelPath;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btn_SelPath = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_SelPath
            // 
            btn_SelPath.BackColor = System.Drawing.Color.LightSalmon;
            btn_SelPath.ForeColor = System.Drawing.Color.DodgerBlue;
            btn_SelPath.Location = new System.Drawing.Point(66, 35);
            btn_SelPath.Name = "btn_SelPath";
            btn_SelPath.Size = new System.Drawing.Size(144, 47);
            btn_SelPath.TabIndex = 0;
            btn_SelPath.Text = "请选择文件夹";
            btn_SelPath.UseVisualStyleBackColor = false;
            btn_SelPath.Click += new System.EventHandler(this.btn_SelPath_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(301, 118);
            this.Controls.Add(btn_SelPath);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
    }
}

